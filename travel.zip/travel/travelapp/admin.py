from django.contrib import admin
from travelapp.models import Product, Amenity, City, HotelProduct, HotelProductImage, ProductImage

from django.contrib import admin
from .models import Orders

admin.site.register(Orders)





class productAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'description', 'state', 'rating','known_for', 'best_time_to_visit', 'price', 'image','full_detail','nearby_place']


# HotelProduct admin
class HotelProductAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'state', 'location', 'price', 'is_available']

# HotelProductImage admin
class HotelProductImageAdmin(admin.ModelAdmin):
    list_display = ['id', 'hotel', 'image']

# ProductImage admin
class ProductImageAdmin(admin.ModelAdmin):
    list_display = ['id', 'product', 'image']



admin.site.register(Product, productAdmin)
admin.site.register(ProductImage, ProductImageAdmin)
admin.site.register(HotelProduct, HotelProductAdmin)
admin.site.register(HotelProductImage, HotelProductImageAdmin)

admin.site.register(Amenity)
admin.site.register(City)




