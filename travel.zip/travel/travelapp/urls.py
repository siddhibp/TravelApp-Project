from django.urls import path
from travelapp import views
from django.conf import settings
from django.conf.urls.static import static
from .views import state_detail_combined, state_detail1, save_user_details

urlpatterns = [
    # ---------- Home & Authentication ----------
    path('', views.index),
    path('register/', views.user_register),
    path('login/', views.user_login),
    path('logout/', views.user_logout),

    # ---------- Products (Places) ----------
    path('products/add', views.product_add),
    path('products/show', views.product_show, name='product_show'),
    path('products/edit/<rid>', views.product_edit),
    path('products/delete/<rid>', views.product_delete),
    path('', views.product_list, name='product_list'),

    # ---------- Product Cart & Orders ----------
    path('add-to-cart/<int:rid>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.show_cart, name='show_cart'),
    path('remove-cart/<int:rid>/', views.remove_cart, name='remove_cart'),
    path('cart/update/<int:rid>/<int:cid>/', views.update_cart, name='update_cart'),
    path('order/add', views.add_to_order, name='add_to_order'),
    path('orders/', views.show_all_orders, name='show_all_orders'),
    path('orders/products/', views.show_product_orders, name='show_product_orders'),

    # ---------- Food ----------
    path('food/add', views.food_add),
    path('showfood', views.food_show, name='showfood'),
    path('food/edit/<rid>', views.food_edit),
    path('food/delete/<rid>', views.food_delete),

    # ---------- Food Cart & Orders ----------
    path('food/add_to_cart/<int:rid>/', views.add_food_to_cart, name='add_food_to_cart'),
    path('food/cart/', views.show_food_cart, name='show_food_cart'),
    path('food/cart/remove/<int:rid>/', views.remove_food_from_cart, name='remove_food_from_cart'),
    path('food/cart/update/<int:rid>/', views.update_food_cart, name='update_food_cart'),
    path('food/order/add/', views.add_food_to_order, name='add_food_to_order'),
    path('food/orders/', views.show_food_orders, name='show_food_orders'),

    # ---------- Hotels ----------
    path('hotel_add/', views.hotel_add, name='hotel_add'),
    path('show_hotels', views.show_hotels, name='show_hotels'),
    path('hotels/edit/<int:rid>/', views.hotel_edit, name='hotel_edit'),
    path('hotel/delete/<rid>', views.hotel_delete, name='hotel_delete'),

    # ---------- Hotel Cart & Orders ----------
    path('add-hotel-to-cart/<int:rid>/', views.add_hotel_to_cart, name='add_hotel_to_cart'),
    path('hotel-cart/', views.show_hotel_cart, name='show_hotel_cart'),
    path('remove-hotel-from-cart/<int:rid>/', views.remove_hotel_from_cart, name='remove_hotel_from_cart'),
    path('update-hotel-cart/<int:rid>/', views.update_hotel_cart, name='update_hotel_cart'),
    path('hotel/order/add/', views.add_hotel_to_order, name='add_hotel_to_order'),
    path('hotel-orders', views.show_hotel_orders, name='show_hotel_orders'),

    # ---------- Review Routes ----------
    # Product Review
    path('review/add/<int:rid>/', views.add_review, name='add_review'),
    path('review/show/<int:prod_id>/', views.see_product_reviews, name='see_product_reviews'),

    # Food Review
    path('food/review/<int:fid>/<int:oid>/', views.add_food_review, name='add_food_review'),
    path('food/review/show/<int:food_id>/', views.see_food_reviews, name='see_food_reviews'),

    # Hotel Review
    path('hotel/review/<int:hid>/<int:oid>/', views.add_hotel_review, name='add_hotel_review'),
    path('hotel/review/show/<int:hotel_id>/', views.see_hotel_reviews, name='see_hotel_reviews'),

    # ---------- Review Detail (Product) ----------
    path('review/details/<rid>', views.review_details),

    # ---------- Razorpay Payment ----------
    path("save-user-details/", save_user_details, name="save_user_details"),
    path("receipt/<str:payment_id>/", views.receipt, name="receipt"),

    # ---------- Excel Export ----------
    path("export-orders/", views.export_orders_excel, name="export_orders_excel"),

    # ---------- Misc ----------
    path('send_otp', views.send_otp),
    path('verify_otp', views.verify_otp),
    path('update_password', views.update_password),

    # ---------- State Detail Pages ----------
    path('state/detail/<int:rid>/', state_detail_combined, name='state_detail_combined'),
    path('state/detail1/<int:rid>/', state_detail1, name='state_detail1'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
