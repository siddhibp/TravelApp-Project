from django.db import models
from django.contrib.auth.models import User

# Shared type choices
TYPE_CHOICES = [
    ('Rajasthan', 'Rajasthan'),
    ('Himachal Pradesh', 'Himachal Pradesh'),
    ('Uttarakhand', 'Uttarakhand'),
    ('Uttar Pradesh', 'Uttar Pradesh'),
    ('Kerala', 'Kerala'),
    ('Karnataka', 'Karnataka'),
    ('Tamil Nadu', 'Tamil Nadu'),
    ('Andhra Pradesh', 'Andhra Pradesh'),
    ('Sikkim', 'Sikkim'),
    ('Assam', 'Assam'),
    ('Nagaland', 'Nagaland'),
    ('Tripura', 'Tripura'),
    ('Jharkhand', 'Jharkhand'),
    ('Goa', 'Goa'),
    ('Gujarat', 'Gujarat'),
    ('Maharashtra', 'Maharashtra'),
    ('Madhya Pradesh', 'Madhya Pradesh'),
    ('Chhattisgarh', 'Chhattisgarh'),
    ('Jammu and Kashmir', 'Jammu and Kashmir'),
    ('Ladakh', 'Ladakh'),
    ('Andaman and Nicobar', 'Andaman and Nicobar'),
    ('Chandigarh', 'Chandigarh'),
]

class Product(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(blank=True, null=True, max_length=200)
    state = models.CharField(max_length=50, choices=TYPE_CHOICES)
    rating = models.DecimalField(max_digits=2, decimal_places=1, default=0.0)
    known_for = models.TextField(blank=True, null=True)
    best_time_to_visit = models.CharField(max_length=100, blank=True, null=True)
    price = models.IntegerField()
    is_available = models.BooleanField(default=True)
    image = models.FileField(upload_to="images", null=True, max_length=200)
    full_detail = models.TextField(null=True, blank=True, max_length=1000)
    nearby_place = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name

class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='product_images/')

class Amenity(models.Model):
    name = models.CharField(max_length=100)

class City(models.Model):
    name = models.CharField(max_length=100)
    state = models.CharField(max_length=50, choices=TYPE_CHOICES)

class HotelProduct(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    state = models.CharField(max_length=50, choices=TYPE_CHOICES)
    location = models.CharField(max_length=100, blank=True, null=True)
    rating = models.DecimalField(max_digits=2, decimal_places=1, default=0.0)
    review_count = models.PositiveIntegerField(default=0)
    price = models.IntegerField()
    image = models.FileField(upload_to="images", null=True, max_length=200)
    full_detail = models.TextField(blank=True, null=True)
    is_available = models.BooleanField(default=True)
    booking_link = models.URLField(blank=True, null=True)
    amenities = models.ManyToManyField(Amenity, blank=True)
    city = models.ForeignKey(City, on_delete=models.SET_NULL, null=True, blank=True)

class HotelProductImage(models.Model):
    hotel = models.ForeignKey(HotelProduct, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='hotel_images/')

class HotelCart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    hotel = models.ForeignKey(HotelProduct, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    total_price = models.FloatField()

class HotelOrder(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    hotel = models.ForeignKey(HotelProduct, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    order_date = models.DateTimeField(auto_now_add=True)


class FoodItem(models.Model):
    CUISINE_CHOICES = [
        ('indian', 'Indian'),
        ('chinese', 'Chinese'),
        ('italian', 'Italian'),
        ('mexican', 'Mexican'),
        ('thai', 'Thai'),
        ('continental', 'Continental'),
        ('japanese', 'Japanese'),
        ('mediterranean', 'Mediterranean'),
        ('american', 'American'),
    ]
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=50, choices=TYPE_CHOICES)
    location = models.CharField(max_length=100, blank=True, null=True)
    rating = models.DecimalField(max_digits=2, decimal_places=1, default=0.0)
    review_count = models.PositiveIntegerField(default=0)
    price = models.IntegerField()
    is_available = models.BooleanField(default=True)
    image = models.ImageField(upload_to='food_images/')
    cuisine_type = models.CharField(max_length=100, choices=CUISINE_CHOICES)
    timing = models.CharField(max_length=50)

class FoodImage(models.Model):
    food = models.ForeignKey(FoodItem, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='food_images/')

class FoodCart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    food = models.ForeignKey(FoodItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)

class FoodOrder(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    food = models.ForeignKey(FoodItem, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    total_price = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)
    order_date = models.DateTimeField(auto_now_add=True)


class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    prod = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    total_price = models.FloatField(default=0.00)
    is_order = models.BooleanField(default=False)

class Orders(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    prod = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    total_price = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)
    ordered_at = models.DateTimeField(auto_now_add=True)


from django.db import models
from django.contrib.auth.models import User

# Product Reviews (Already exists as "Reviews" in your project)
class Reviews(models.Model):
    RATING_CHOICES = [(i, i) for i in range(1, 6)]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    prod = models.ForeignKey('Product', on_delete=models.CASCADE, related_name='reviews')
    review = models.CharField(max_length=200)
    image = models.ImageField(upload_to='image/reviewImage', blank=True, null=True)
    rating = models.IntegerField(choices=RATING_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} review on {self.prod.name}"

# Food Reviews
class FoodReview(models.Model):
    RATING_CHOICES = [(i, i) for i in range(1, 6)]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    food = models.ForeignKey('FoodItem', on_delete=models.CASCADE, related_name='reviews')
    review = models.TextField()
    rating = models.IntegerField(choices=RATING_CHOICES)
    order = models.ForeignKey('FoodOrder', on_delete=models.CASCADE, null=True, blank=True)
    image = models.ImageField(upload_to='image/food_reviews/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} review on {self.food.name}"

# Hotel Reviews
class HotelReview(models.Model):
    RATING_CHOICES = [(i, i) for i in range(1, 6)]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    hotel = models.ForeignKey('HotelProduct', on_delete=models.CASCADE, related_name='reviews')
    review = models.TextField()
    rating = models.IntegerField(choices=RATING_CHOICES)
    order = models.ForeignKey('HotelOrder', on_delete=models.CASCADE, null=True, blank=True)
    image = models.ImageField(upload_to='image/hotel_reviews/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} review on {self.hotel.name}"
