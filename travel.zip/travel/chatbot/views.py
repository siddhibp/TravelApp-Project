from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json

@csrf_exempt
def chatbot_response(request):
    user_message = request.GET.get('message', '')

    if not user_message:
        return JsonResponse({"response": "Please type something to ask!"})

    # Lowercase for case-insensitive matching
    message = user_message.lower()

    # Keyword-based logic for travel chatbot
    if "hello" in message or "hi" in message:
        reply = "Hello! I’m your travel assistant. How can I help you today?"
    elif "places" in message or "tourist spot" in message:
        reply = "You can explore popular tourist spots in the 'Destinations' section."
    elif "hotels" in message or "stay" in message:
        reply = "Check out the best hotel options under each destination page."
    elif "best time" in message:
        reply = "Each destination page shows the best time to visit. Let me know which place you're asking about!"
    elif "price" in message or "cost" in message:
        reply = "Prices vary by destination. You can find pricing details listed on each place's detail page."
    elif "how to book" in message or "booking" in message:
        reply = "You can book through the respective travel provider's link mentioned on the site."
    elif "contact" in message or "support" in message:
        reply = "For support, please visit the 'Contact Us' page or send us a message."
    elif "visa" in message or "passport" in message:
        reply = "Visa requirements differ by country. Visit the 'Travel Info' section for visa guidance."
    elif "weather" in message or "temperature" in message:
        reply = "Weather info is listed on each destination page. Would you like to check a specific place?"
    elif "activities" in message or "adventure" in message:
        reply = "Explore exciting activities in the 'Things to Do' section of each destination."
    elif "food" in message or "restaurants" in message:
        reply = "You’ll find popular food and restaurant options under the 'Eat & Drink' section."
    elif "budget" in message or "cheap" in message:
        reply = "Use our filters to find destinations and hotels that suit your budget."
    elif "family" in message or "kids" in message:
        reply = "We recommend family-friendly places and activities. Check out the 'Family Trips' section."
    elif "honeymoon" in message or "romantic" in message:
        reply = "Looking for a romantic escape? Check out our 'Honeymoon Getaways' section."
    elif "language" in message or "speak" in message:
        reply = "You can check what languages are spoken under the destination's travel guide."
    elif "transport" in message or "how to reach" in message:
        reply = "Transportation info including road, rail, and air options is available on each destination page."
    elif "safety" in message or "covid" in message:
        reply = "We care about your safety. Please read the latest health and safety tips in our 'Travel Advisory'."
    elif "plan" in message or "itinerary" in message:
        reply = "Need help planning? Use our travel itinerary suggestions to make the most of your trip."
    elif "guide" in message or "local guide" in message:
        reply = "Local guides are listed on some destinations. You can contact them directly through the details given."
    else:
        reply = "Sorry, I didn’t understand that. Could you please rephrase your question?"

    return JsonResponse({"response": reply})
