#forms 
from django import forms
from travelapp.models import Product, ProductImage,HotelProduct,HotelProductImage
from django.contrib.auth.models import User
from django.forms import modelformset_factory


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields =  [ 'name', 'description', 'state', 'rating','known_for', 'best_time_to_visit', 'price', 'image','full_detail','nearby_place'] #add near by place 

class ProductImageForm(forms.ModelForm):
    class Meta:
        model = ProductImage
        fields = ['image']


class UpdateProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'state', 'rating','known_for', 'best_time_to_visit', 'price', 'image','is_available','full_detail','nearby_place']#add near by place 
        



from django import forms
from .models import HotelProduct, HotelProductImage, ProductImage

# Formset for multiple hotel images
HotelImageFormSet = modelformset_factory(HotelProductImage, form=forms.modelform_factory(HotelProductImage, fields=['image']), extra=3)

class HotelProductForm(forms.ModelForm):
    class Meta:
        model = HotelProduct
        fields = [
            'name', 'description', 'state', 'location', 'rating', 'review_count',
            'price', 'full_detail', 'is_available', 'booking_link', 'image',
            'amenities', 'city'
        ]
        widgets = {
            'amenities': forms.CheckboxSelectMultiple(),
            'Rooms': forms.RadioSelect()
        }

class HotelProductImageForm(forms.ModelForm):
    class Meta:
        model = HotelProductImage
        fields = ['image']

# Formset for general product images
ProductImageFormSet = modelformset_factory(ProductImage, form=forms.modelform_factory(ProductImage, fields=['image']), extra=3)


class UpdateHotelProductForm(forms.ModelForm):
    class Meta:
        model = HotelProduct
        fields = ['name', 'description', 'state', 'location', 'rating', 'review_count',
                    'price', 'full_detail', 'is_available', 'booking_link', 'image',
                    'amenities', 'city'] 
                    
                    #remove stars needed, remove best_time_to_visit
                    #add city, rooms, Amenities  
                    #rename full_detail to state detail guide with famous place
                                                                                                    
class HotelProductImageForm(forms.ModelForm):
    class Meta:
        model = HotelProductImage
        fields = ['image']

# Formset for multiple hotel product images
HotelProductImageFormSet = modelformset_factory(HotelProductImage, form=HotelProductImageForm, extra=3)








from django import forms
from travelapp.models import FoodItem, FoodImage
from django.forms import modelformset_factory

class FoodForm(forms.ModelForm):
    class Meta:
        model = FoodItem
        fields = [
            'name', 'city', 'state', 'location', 'rating', 'review_count',
            'price', 'is_available', 'image', 'cuisine_type', 'timing'
        ]  

class FoodImageForm(forms.ModelForm):
    class Meta:
        model = FoodImage
        fields = ['image']

class UpdateFoodForm(forms.ModelForm):
    class Meta:
        model = FoodItem
        fields = [
            'name', 'city', 'state', 'location', 'rating', 'review_count',
            'price', 'is_available', 'image', 'cuisine_type', 'timing'
        ]















class RegisterUserForm(forms.ModelForm):
  
    password= forms.CharField(max_length=10,widget=forms.PasswordInput)
    password2 =forms.CharField(max_length=10,widget=forms.PasswordInput)

    class Meta:                 
        model = User
        fields = ['username','first_name','last_name','email','password','password2']
        exclude =['last_login','is_superuser','is_staff','is_active','date_joined']


class LoginUserForm(forms.Form):    
    username = forms.CharField(max_length=50)
    password = forms.CharField(max_length=10, widget=forms.PasswordInput)
    

