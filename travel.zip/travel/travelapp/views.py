from django.shortcuts import render,HttpResponse,redirect
from travelapp.forms import ProductForm,UpdateProductForm ,RegisterUserForm,LoginUserForm #for add product form
from travelapp.models import Product, Cart ,Orders,Reviews
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.sessions.models import Session
from django.db.models import Avg
from django.conf import settings
from django.core.mail import get_connection, EmailMessage
from .forms import ProductForm, ProductImageFormSet,UpdateHotelProductForm
from .models import Product, ProductImage
from .models import ProductImage


from .forms import HotelProductForm, HotelProductImageForm
from .models import HotelProduct, HotelProductImage
from django.forms import modelformset_factory

from django.contrib.auth.models import User
import random
import razorpay



def index(request):
    return render(request, 'index.html')

def user_register(request):
  
    form = RegisterUserForm(request.POST)    #all data from reg.html going save in form vari
    if request.method == "POST" and form.is_valid():

        password =form.cleaned_data['password']     #like od method(fillter) we using cleaned_data to fetch password. form.cleaned_data form- from form filter password
        password2= form.cleaned_data['password2']

        if password != password2:
            context ={}
            context['msg']= 'Password & Confirm password is not match '
            context['form'] = form
            return render (request,'registration.html',context)
        
        else:
            user = form.save(commit=True) # before saving data come from form we need to update form before save to show password in encrypt format
            user.set_password(password)
            user.save()
            context ={}

            context['msg'] = "User Registered Successfully"
            context['form'] = form

            return redirect("/login")

    else:
         form = RegisterUserForm()
         context ={}
         context['form'] = form
         return render(request,'registration.html',context)
  

def user_login(request):
    form= LoginUserForm(request.POST)
    if request.method=="POST" and form.is_valid():
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        
        user = authenticate(username= username, password= password)

        if user is not None:
            login(request,user)
            return redirect('/')
        
    else:
        form = LoginUserForm
        context = {}
        context['form'] = form
        return render(request,'login.html',context)
    
def your_view(request):
    context = {
        'is_logged_in': request.user.is_authenticated,
        # Add other context variables here
    }
    return render(request, 'your_template.html', context)


def user_logout(request):
    logout(request)
    return redirect('/')


def send_otp(request):
  
    if request.method == "GET":
        return render(request, 'send_otp.html')
    else:

        email = request.POST['email']
        request.session['email'] = email
        user = User.objects.filter(email = email)

        if user is not None:
            otp = random.randint(1000,9999)
            request.session['otp'] = otp

            with get_connection(
                host = settings.EMAIL_HOST,
                port = settings.EMAIL_PORT,
                username = settings.EMAIL_HOST_USER,
                password = settings.EMAIL_HOST_PASSWORD,
                use_tls = settings.EMAIL_USE_TLS
            ) as connection :
                subject = "OTP Verfication"
                email_from = settings.EMAIL_HOST_USER
                recipetion_list = [ email ]
                message = f" Thank you for using our game app Otp is {otp}."
                
                EmailMessage(subject, message, email_from, recipetion_list, connection = connection).send()

                return redirect('/verify_otp')
        else:
                return HttpResponse("user not Found")

def verify_otp(request):
    
    if request.method =="GET":
        return render(request,'verify_otp.html')
    
    else:
        otp = request.session['otp']
        user_otp = request.POST['otp']
        otp = int(otp)
        user_otp = int(user_otp)

        if otp == user_otp:
            return redirect('/update_password')
        else:
            return HttpResponse('otp not same')


def update_password(request):
    
    if request.method == "GET":
        return render (request,'update_password.html')       

    else:
        email= request.session['email']
        user = User.objects.get(email = email)
        
        new_password = request.POST['new_Password']
        confirm_password = request.POST['confirm_Password']

        if new_password == confirm_password:
            user.set_password(new_password)
            user.save()
            return redirect('/login')
        else:
            return HttpResponse ("Password and Confirm Password must be same")
        
        


def product_add(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        formset = ProductImageFormSet(request.POST, request.FILES, queryset=ProductImage.objects.none())

        if form.is_valid() and formset.is_valid():
            product = form.save()
            for image_form in formset:
                if image_form.cleaned_data.get('image'):
                    image = image_form.save(commit=False)
                    image.product = product
                    image.save()
            return redirect('/products/show')
    else:
        form = ProductForm()
        formset = ProductImageFormSet(queryset=ProductImage.objects.none())

    return render(request, 'product_add.html', {
        'form': form,
        'formset': formset,  # This matches what your template expects
    })


from django.db.models import Q, Avg

def product_show(request):
    search_query = request.GET.get('search', '')
    products = Product.objects.all()

    if search_query:
        products = products.filter(
            Q(name__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(state__icontains=search_query) |
            Q(known_for__icontains=search_query) |
            Q(best_time_to_visit__icontains=search_query)
        )

    rating = {}
    for product in products:
        rate = Reviews.objects.filter(prod=product).aggregate(Avg('rating'))['rating__avg']
        rating[product.id] = rate

    context = {
        'data': products,
        'search_query': search_query,
        'rate': rating,
    }

    return render(request, 'showproduct.html', context)

def product_edit(request,rid):
    obj = Product.objects.get(id = rid )
    if request.method== "POST":
        form = UpdateProductForm(request.POST, request.FILES, instance= obj)
        form.save()
        return redirect ('/products/show')
    else:
        obj = Product.objects.get(id =rid)
        form = UpdateProductForm(instance= obj)
        context ={}
    context['form'] =form
    return render(request,'editproduct.html',context)

def product_delete(request, rid):
    obj = Product.objects.filter(id = rid)
    obj.delete()   
    return redirect('/products/show')





def state_detail_combined(request, rid):
    # Get the current place/product
    prod = get_object_or_404(Product, id=rid)

    # Get reviews for current place
    reviews = Reviews.objects.filter(prod=prod)
    avg = reviews.aggregate(Avg('rating'))
    avgrating = avg['rating__avg'] or 0

    # Prepare data for state_detail1 section
    product_data = {
        'id': prod.id,
        'name': prod.name,
        'is_available': prod.is_available,
        'description': prod.description,
        'state': prod.state,
        'country': 'India',
        'rating': prod.rating,
        'votes': reviews.count(),
        'known_for': prod.known_for,
        'best_time_to_visit': prod.best_time_to_visit,
        'image': prod.image,
        'price': prod.price,
        'full_detail': prod.full_detail,
        'nearby_place': prod.nearby_place,
    }

    # Get nearby places for state_detail2 section (exclude current place)
    nearby_places = Product.objects.filter(nearby_place=prod.nearby_place).exclude(id=prod.id)

    # Get only 3 places for showing next data
    other_places = nearby_places[:3]

    # Put both datasets in context
    context = {
        'data': [product_data],         # for your first section (state_detail1)
        'current_place': prod,          # for reference in second section
        'data2': nearby_places,         # for your second section (full nearby)
        'other_places': other_places,   # NEW: only 3 places for next section
        'reviews': reviews,
        'avgrating': avgrating,
    }

    # Render one template with all data
    return render(request, 'state_detail_combined.html', context)


from django.shortcuts import render, get_object_or_404
from .models import Product, Reviews
from django.db.models import Avg

def state_detail1(request, rid):
    # Get the selected product/place
    prod = get_object_or_404(Product, id=rid)

    # Get reviews for the product
    reviews = Reviews.objects.filter(prod=prod)
    avg = reviews.aggregate(Avg('rating'))
    avgrating = avg['rating__avg'] or 0

    # Get nearby places excluding the current one
    nearby_places = Product.objects.filter(nearby_place=prod.nearby_place).exclude(id=prod.id)

    context = {
        'data': [prod],  # For loop in template
        'reviews': reviews,
        'avgrating': avgrating,
        'nearby_places': nearby_places,  # optional, if used in template
    }
    return render(request, 'state_detail1.html', context)





from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import redirect, get_object_or_404
from .models import Product, Cart  # Ensure these are correctly imported

@login_required(login_url="/login")
def add_to_cart(request, rid):
    product = get_object_or_404(Product, id=rid)
    cart_item, created = Cart.objects.get_or_create(user=request.user, prod=product)

    if created:
        cart_item.quantity = 1
        cart_item.total_price = product.price
        messages.success(request, "Product added to cart.")
    else:
        cart_item.quantity += 1
        cart_item.total_price = cart_item.quantity * product.price
        messages.info(request, "Product already in cart")

    cart_item.save()
    
    return redirect('show_cart')  # ✅ redirect to cart page


def show_cart(request):
  
    cart = Cart.objects.filter(user = request.user)
    
    total_quantity = 0
    total_price = 0
    
    for x in cart:
        total_quantity += x.quantity
        total_price += x.prod.price * x.quantity

    context = {}
    context['data'] = cart
    context['total_quantity'] = total_quantity
    context['total_price']= total_price
    return render(request, 'cart.html',context)

def remove_cart(request,rid):
    c =Cart.objects.filter(id=rid)
    c.delete()
    return redirect('/cart') 

def update_cart(request, rid, cid):
    if request.method == "POST":
        quantity = int(request.POST.get("quantity"))
        cart_item = get_object_or_404(Cart, id=rid, prod__id=cid, user=request.user)
        cart_item.quantity = quantity
        cart_item.total_price = quantity * cart_item.prod.price
        cart_item.save()
    return redirect('/cart')

def product_list(request):
    products = Product.objects.all()

    cart_product_ids = Cart.objects.filter(user=request.user).values_list('product_id', flat=True)

    return render(request, 'product_list.html', {
        'products': products,
        'cart_product_ids': list(cart_product_ids),  # Important to convert to list!
    })


def previous_order(request):
    return render(request,'order.html')

from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
import razorpay
from .models import Cart, Orders, HotelCart, HotelOrder

# ✔️ 1. Show product orders
def show_product_orders(request):
    obj = Orders.objects.filter(user=request.user)
    context = {'data': obj}
    return render(request, "order.html", context)

# ✔️ 2. Add product order
def add_to_order(request):
    cart = Cart.objects.filter(user=request.user)
    total_price = 0

    for x in cart:
        prod = x.prod
        quantity = x.quantity
        price = x.total_price
        total_price += price

        Orders.objects.create(user=request.user, prod=prod, quantity=quantity, total_price=price)

    if total_price < 1:
        messages.error(request, "Minimum order amount must be at least ₹1.00.")
        return redirect('show_cart')

    client = razorpay.Client(auth=(settings.KEY, settings.SECRET))
    payment = client.order.create({
        'amount': int(total_price * 100),
        'currency': 'INR',
        'payment_capture': 1
    })

    cart.delete()
    return render(request, 'payment.html', {'payment': payment})






def hotel_add(request):
    if request.method == 'POST':
        hotel_form = HotelProductForm(request.POST, request.FILES)
        image_formset = HotelImageFormSet(request.POST, request.FILES, queryset=HotelProductImage.objects.none())

        if hotel_form.is_valid() and image_formset.is_valid():
            hotel = hotel_form.save(commit=False)
            hotel.is_available = True
            hotel.save()
            hotel_form.save_m2m()

            for form in image_formset:
                if form.cleaned_data.get('image'):
                    image = form.save(commit=False)
                    image.hotel = hotel
                    image.save()

            return redirect('/show_hotels')
        else:
            # Form is invalid, render the form with errors
            return render(request, 'add_hotel.html', {
                'hotel_form': hotel_form,
                'image_formset': image_formset
            })

    else:
        hotel_form = HotelProductForm()
        image_formset = HotelImageFormSet(queryset=HotelProductImage.objects.none())

    return render(request, 'add_hotel.html', {
        'hotel_form': hotel_form,
        'image_formset': image_formset
    })

from django.db.models import Q
from .models import HotelProduct, Amenity  # Make sure Amenity is imported

def show_hotels(request):
    search_query = request.GET.get('search', '')
    selected_amenities = request.GET.getlist('amenities')

    # ✅ NEW: Get values from guests form
    adults = request.GET.get('adults', '2')      # default 2 adults
    children = request.GET.get('children', '0')  # default 0 children
    rooms = request.GET.get('rooms', '1')        # default 1 room

    hotels = HotelProduct.objects.filter(is_available=True)

    if search_query:
        hotels = hotels.filter(
            Q(name__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(state__icontains=search_query) |
            Q(location__icontains=search_query)
        )

    if selected_amenities:
        hotels = hotels.filter(amenities__id__in=selected_amenities).distinct()

    state = hotels.first().state if hotels.exists() and search_query else None
    full_detail = hotels.first().full_detail if hotels.exists() and search_query else None

    context = {
        'data': hotels,
        'search_query': search_query,
        'state': state,
        'full_detail': full_detail,
        'all_amenities': Amenity.objects.all(),
        'selected_amenities': list(map(int, selected_amenities)),

        # ✅ Pass guest form values back to template
        'adults': adults,
        'children': children,
        'rooms': rooms,
    }

    return render(request, 'show_hotels.html', context)

from django.shortcuts import render, get_object_or_404, redirect
from .models import HotelProduct, HotelProductImage
from .forms import HotelProductForm, HotelProductImageForm,UpdateHotelProductForm
from django.forms import modelformset_factory

# Formset for hotel images
from django.forms import inlineformset_factory

HotelImageFormSet = inlineformset_factory(
    HotelProduct, HotelProductImage,
    form=HotelProductImageForm,
    fields=['image'],  # include other fields if needed
    extra=3,
    can_delete=True
)
def hotel_edit(request, rid):
    obj = HotelProduct.objects.get(id=rid)  # Define once at the start

    if request.method == 'POST':
        hotel_form = UpdateHotelProductForm(request.POST, instance=obj)  # Use UpdateHotelProductForm
        if hotel_form.is_valid():
            hotel_form.save()
            return redirect('/show_hotels')
    else:
        hotel_form = UpdateHotelProductForm(instance=obj)

    context = {
        'hotel_form': hotel_form,
    }

    return render(request, 'edit_hotel.html', context)



import os
from django.shortcuts import get_object_or_404, redirect

def hotel_delete(request, rid):
    hotel = get_object_or_404(HotelProduct, id=rid)
    if hotel.image:
        image_path = os.path.join(settings.MEDIA_ROOT, hotel.image.name)
        if os.path.isfile(image_path):
            os.remove(image_path)

    hotel.delete()         

    return redirect('/show_hotels')


from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import HotelProduct, HotelCart

# ✅ Add hotel to cart
@login_required(login_url="/login")
def add_hotel_to_cart(request, rid):
    hotel = get_object_or_404(HotelProduct, id=rid)

    cart_item, created = HotelCart.objects.get_or_create(
        user=request.user,
        hotel=hotel,
        defaults={
            'quantity': 1,
            'total_price': hotel.price
        }
    )

    if not created:
        cart_item.quantity += 1
        cart_item.total_price = cart_item.quantity * hotel.price
        cart_item.save()
        messages.info(request, "Hotel already in cart.")
    else:
        messages.success(request, "Hotel added to cart.")

    return redirect('show_hotel_cart')


# ✅ Show hotel cart
@login_required(login_url="/login")
def show_hotel_cart(request):
    cart = HotelCart.objects.filter(user=request.user)
    
    total_quantity = sum(item.quantity for item in cart)
    total_price = sum(item.total_price for item in cart)

    return render(request, 'hotel_cart.html', {
        'data': cart,
        'total_quantity': total_quantity,
        'total_price': total_price
    })

# ✅ Remove hotel from cart
@login_required(login_url="/login")
def remove_hotel_from_cart(request, rid):
    cart_item = get_object_or_404(HotelCart, id=rid, user=request.user)
    cart_item.delete()
    messages.success(request, "Hotel removed from cart.")
    return redirect('show_hotel_cart')


# ✅ Update hotel cart quantity (via POST form)
@login_required(login_url="/login")
def update_hotel_cart(request, rid):
    if request.method == "POST":
        quantity = int(request.POST.get("quantity"))
        cart_item = get_object_or_404(HotelCart, id=rid, user=request.user)
        cart_item.quantity = quantity
        cart_item.total_price = quantity * cart_item.hotel.price
        cart_item.save()
        messages.success(request, "Hotel cart updated.")
    return redirect('show_hotel_cart')



# ✔️ 3. Show hotel orders
def show_hotel_orders(request):
    obj = HotelOrder.objects.filter(user=request.user)
    context = {'data': obj}
    return render(request, "order.html", context)

# ✔️ 4. Add hotel order
def add_hotel_to_order(request):
    cart = HotelCart.objects.filter(user=request.user)
    total_price = 0

    if not cart.exists():
        messages.error(request, "Your hotel cart is empty.")
        return redirect('show_hotel_cart')

    for item in cart:
        total_price += item.total_price

    if total_price < 1:
        messages.error(request, "Minimum order amount must be at least ₹1.00.")
        return redirect('show_hotel_cart')

    for item in cart:
        HotelOrder.objects.create(
            user=request.user,
            hotel=item.hotel,
            quantity=item.quantity,
            total_price=item.total_price
        )

    client = razorpay.Client(auth=(settings.KEY, settings.SECRET))
    payment = client.order.create({
        'amount': int(total_price * 100),
        'currency': 'INR',
        'payment_capture': 1
    })

    cart.delete()
    return render(request, 'hotelpayment.html', {'payment': payment})







from django.shortcuts import render, redirect, get_object_or_404
from .models import FoodItem
from .forms import FoodForm
from django.db.models import Q

# CREATE
def food_add(request):
    if request.method == 'POST':
        form = FoodForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('showfood')
    else:
        form = FoodForm()
    return render(request, 'food_add.html', {'form': form})


# READ (LIST + SEARCH)
def food_show(request):
    search_query = request.GET.get('search', '')
    foods = FoodItem.objects.all()

    if search_query:
        foods = foods.filter(
            Q(name__icontains=search_query) |
            Q(city__icontains=search_query) |
            Q(state__icontains=search_query) |
            Q(location__icontains=search_query) |
            Q(cuisine_type__icontains=search_query)
        )
    
    return render(request, 'showfood.html', {'data': foods, 'search_query': search_query})


# UPdATE
def food_edit(request, rid):
    obj = get_object_or_404(FoodItem, id=rid)
    if request.method == 'POST':
        form = FoodForm(request.POST, request.FILES, instance=obj)
        if form.is_valid():
            form.save()
            return redirect('showfood')
    else:
        form = FoodForm(instance=obj)
    return render(request, 'editfood.html', {'form': form})


# DELETE
def food_delete(request, rid):
    obj = get_object_or_404(FoodItem, id=rid)
    obj.delete()
    return redirect('showfood')


from .models import FoodItem, FoodCart, FoodOrder
from django.contrib.auth.decorators import login_required
from django.contrib import messages
import razorpay
from django.conf import settings

# Add food to cart
@login_required(login_url='/login')
def add_food_to_cart(request, rid):
    food = get_object_or_404(FoodItem, id=rid)

    cart_item, created = FoodCart.objects.get_or_create(
        user=request.user,
        food=food,
        defaults={
            'quantity': 1,
            'total_price': food.price
        }
    )

    if not created:
        cart_item.quantity += 1
        cart_item.total_price = cart_item.quantity * food.price
        cart_item.save()
        messages.info(request, "Food item already in cart")
    else:
        messages.success(request, "Food item added to cart.")

    return redirect('show_food_cart')


# Show food cart
@login_required(login_url='/login')
def show_food_cart(request):
    cart = FoodCart.objects.filter(user=request.user)
    total_quantity = sum(item.quantity for item in cart)
    total_price = sum(item.total_price for item in cart)

    return render(request, 'food_cart.html', {
        'data': cart,
        'total_quantity': total_quantity,
        'total_price': total_price
    })


# Remove food from cart
@login_required(login_url='/login')
def remove_food_from_cart(request, rid):
    item = get_object_or_404(FoodCart, id=rid, user=request.user)
    item.delete()
    messages.success(request, "Food item removed from cart.")
    return redirect('show_food_cart')


from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect
from .models import FoodCart  # Make sure this is correct

@login_required(login_url='/login')
def update_food_cart(request, rid):
    if request.method == 'POST':
        quantity = int(request.POST.get("quantity"))

        # ✅ Use both ID and user to avoid unauthorized access or 404
        cart_item = get_object_or_404(FoodCart, id=rid, user=request.user)

        cart_item.quantity = quantity
        cart_item.total_price = quantity * cart_item.food.price
        cart_item.save()
    return redirect('show_food_cart')


# Place food order
@login_required(login_url='/login')
def add_food_to_order(request):
    cart = FoodCart.objects.filter(user=request.user)
    total_price = sum(item.total_price for item in cart)

    if not cart.exists():
        messages.error(request, "Your food cart is empty.")
        return redirect('show_food_cart')

    if total_price < 1:
        messages.error(request, "Minimum order amount must be at least ₹1.00.")
        return redirect('show_food_cart')

    for item in cart:
        FoodOrder.objects.create(
            user=request.user,
            food=item.food,
            quantity=item.quantity,
            total_price=item.total_price
        )

    # Razorpay integration
    client = razorpay.Client(auth=(settings.KEY, settings.SECRET))
    payment = client.order.create({
        'amount': int(total_price * 100),
        'currency': 'INR',
        'payment_capture': 1
    })

    cart.delete()
    return render(request, 'foodpayment.html', {'payment': payment})


# Show food orders
@login_required(login_url='/login')
def show_food_orders(request):
    orders = FoodOrder.objects.filter(user=request.user)
    return render(request, 'food_orders.html', {'data': orders})




from django.shortcuts import render
from .models import Orders, FoodOrder, HotelOrder
from django.contrib.auth.decorators import login_required

@login_required
def show_all_orders(request):
    product_orders = Orders.objects.filter(user=request.user).order_by('-created_at')  # OK
    food_orders = FoodOrder.objects.filter(user=request.user).order_by('-order_date')  # ✅ FIXED
    hotel_orders = HotelOrder.objects.filter(user=request.user).order_by('-order_date')  # ✅ FIXED

    context = {
        'product_orders': product_orders,
        'food_orders': food_orders,
        'hotel_orders': hotel_orders,
    }

    return render(request, 'order.html', context)



from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, Reviews
from django.contrib.auth.decorators import login_required

@login_required
def add_review(request, rid):                         #product/places
    p = get_object_or_404(Product, id=rid)

    try:
        # Try to get existing review
        review = Reviews.objects.get(user=request.user, prod=p)
    except Reviews.DoesNotExist:
        review = None

    if request.method == 'POST':
        r = request.POST['review']
        s = request.POST['rating']
        i = request.FILES.get('image')  # Use .get() in case no image is uploaded

        if review:
            # Update existing review
            review.review = r
            review.rating = s
            if i:
                review.image = i
            review.save()
        else:
            # Create new review
            Reviews.objects.create(user=request.user, prod=p, review=r, rating=s, image=i)

        return redirect('/orders')

    else:
        if review:
            # Show edit review form
            return render(request, 'editreview.html', {'data': review})
        else:
            # Show new review form
            return render(request, 'review.html', {'product': p})
        


from django.shortcuts import render, redirect, get_object_or_404
from .models import HotelProduct, HotelOrder, HotelReview
from .models import FoodItem, FoodOrder, FoodReview


def add_hotel_review(request, hid, oid):
    hotel = get_object_or_404(HotelProduct, id=hid)
    order = get_object_or_404(HotelOrder, id=oid, hotel=hotel, user=request.user)

    review = HotelReview.objects.filter(user=request.user, hotel=hotel, order=order).first()

    if request.method == 'POST':
        r = request.POST.get('review')
        s = request.POST.get('rating')
        i = request.FILES.get('image')

        if review:
            review.review = r
            review.rating = s
            if i:
                review.image = i
            review.save()
        else:
            HotelReview.objects.create(
                user=request.user,
                hotel=hotel,
                order=order,
                review=r,
                rating=s,
                image=i
            )

        return redirect('/orders')

    return render(request, 'hotelreview.html', {'data': review})


def add_food_review(request, fid, oid):
    food = get_object_or_404(FoodItem, id=fid)
    order = get_object_or_404(FoodOrder, id=oid, food=food, user=request.user)

    review = FoodReview.objects.filter(user=request.user, food=food, order=order).first()

    if request.method == 'POST':
        r = request.POST.get('review')
        s = request.POST.get('rating')
        i = request.FILES.get('image')

        if review:
            review.review = r
            review.rating = s
            if i:
                review.image = i
            review.save()
        else:
            FoodReview.objects.create(
                user=request.user,
                food=food,
                order=order,
                review=r,
                rating=s,
                image=i
            )

        return redirect('/orders')

    return render(request, 'foodreview.html', {'data': review})



def review_details(request,rid):
    prod = Product.objects.get(id = rid)
    review = Reviews.objects.filter(prod = prod)
    
    avg= Reviews.objects.filter(prod = prod).aggregate(Avg('rating'))
    
    avgrating= (avg['rating__avg'])
    
    context = {}
    context['data'] = review
    
    context['rating'] = avgrating
    return render(request,'reviewdetails.html',context)



from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.conf import settings
import razorpay
def receipt(request, payment_id):
    client = razorpay.Client(auth=(settings.KEY, settings.SECRET))
    payment = client.payment.fetch(payment_id)  # ✅ will now be a valid pay_XXXX ID

    user_details = request.session.get('user_details', {})

    context = {
        'payment': payment,
        'amount': payment['amount'] / 100,
        'currency': payment['currency'],
        'status': payment['status'],
        'order_id': payment.get('order_id'),
        'method': payment['method'],
        'created_at': payment['created_at'],
        'fullname': user_details.get('fullname'),
        'email': user_details.get('email'),
        'mobile': user_details.get('mobile'),
        'address': user_details.get('address'),
        'city': user_details.get('city'),
        'state': user_details.get('state'),
        'pincode': user_details.get('pincode'),
        'payment_mode': user_details.get('payment_mode'),
    }

    html = render_to_string('receipt.html', context)

    email = EmailMessage(
        subject='🧾 Your Payment Receipt',
        body=html,
        from_email=settings.EMAIL_HOST_USER,
        to=[user_details.get('email')],
    )
    email.content_subtype = 'html'
    email.send(fail_silently=False)

    return render(request, 'receipt.html', context)


import json
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

@csrf_exempt
def save_user_details(request):
    if request.method == "POST":
        data = json.loads(request.body)
        request.session['user_details'] = {
            'fullname': data.get('fullname'),
            'email': data.get('email'),
            'mobile': data.get('mobile'),
            'address': data.get('address'),
            'city': data.get('city'),
            'state': data.get('state'),
            'pincode': data.get('pincode'),
            'payment_mode': data.get('payment_mode'),
        }
        return JsonResponse({"status": "success"})
    return JsonResponse({"status": "error"}, status=400)



import openpyxl
from django.http import HttpResponse
from .models import Orders, FoodOrder, HotelOrder  # adjust as needed

def export_orders_excel(request):
    wb = openpyxl.Workbook()
    ws1 = wb.active
    ws1.title = "Product Orders"
    ws2 = wb.create_sheet(title="Food Orders")
    ws3 = wb.create_sheet(title="Hotel Orders")

    # Product Orders
    ws1.append(['S.No', 'Place Name', 'Description', 'Quantity', 'Total Price', 'Ordered At'])
    for i, order in enumerate(Orders.objects.all(), start=1):
        ws1.append([
            i,
            order.prod.name,
            order.prod.description,
            order.quantity,
            order.total_price,
            order.ordered_at.strftime("%d-%m-%Y %H:%M")
        ])

    # Food Orders
    ws2.append(['S.No', 'Food Name', 'City', 'Quantity', 'Total Price', 'Ordered At'])
    for i, order in enumerate(FoodOrder.objects.all(), start=1):
        ws2.append([
            i,
            order.food.name,
            order.food.city,
            order.quantity,
            order.total_price,
            order.order_date.strftime("%d-%m-%Y %H:%M")
        ])

    # Hotel Orders
    ws3.append(['S.No', 'Hotel Name', 'Location', 'State', 'Nights', 'Total Price', 'Ordered At'])
    for i, order in enumerate(HotelOrder.objects.all(), start=1):
        ws3.append([
            i,
            order.hotel.name,
            order.hotel.location,
            order.hotel.state,
            order.quantity,
            order.total_price,
            order.order_date.strftime("%d-%m-%Y %H:%M")
        ])

    response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    response['Content-Disposition'] = 'attachment; filename=OrderHistory.xlsx'
    wb.save(response)
    return response


# Product Reviews
def see_product_reviews(request, prod_id):
    product = get_object_or_404(Product, id=prod_id)
    reviews = Reviews.objects.filter(prod=product)
    
    user_review = Reviews.objects.filter(prod=product, user=request.user).first() if request.user.is_authenticated else None
    
    return render(request, "showreview.html", {
        "type": "Place",  # used in template logic
        "item": product,
        "reviews": reviews,
        "user_review": user_review,
        "order_id": None  # not used for products, but needed for template consistency
    })


# Food Reviews
def see_food_reviews(request, food_id):
    food = get_object_or_404(FoodItem, id=food_id)
    reviews = FoodReview.objects.filter(food=food)

    # Get the current user's review and order (if exists)
    user_review = FoodReview.objects.filter(food=food, user=request.user).first()
    order_id = user_review.order.id if user_review else None

    return render(request, "showreview.html", {
        "type": "Food",
        "item": food,
        "reviews": reviews,
        "user_review": user_review,
        "order_id": order_id
    })


# Hotel Reviews
def see_hotel_reviews(request, hotel_id):
    hotel = get_object_or_404(HotelProduct, id=hotel_id)
    reviews = HotelReview.objects.filter(hotel=hotel)

    user_review = HotelReview.objects.filter(hotel=hotel, user=request.user).first()
    order_id = user_review.order.id if user_review else None

    return render(request, "showreview.html", {
        "type": "Hotel",
        "item": hotel,
        "reviews": reviews,
        "user_review": user_review,
        "order_id": order_id
    })
